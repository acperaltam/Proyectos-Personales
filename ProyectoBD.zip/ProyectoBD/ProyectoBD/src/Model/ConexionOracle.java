/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Steven
 */
import java.sql.*;

public class ConexionOracle {

    private Connection conexion;

    public ConexionOracle(String nombre, String contrasena) throws SQLException {
    
        DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

            String nombre_servidor = "127.0.0.1";
            String numero_puerto = "1521";
            String sid = "XE";
            String url = "jdbc:oracle:thin:@" + nombre_servidor + ":" + numero_puerto + ":" + sid;

            conexion = DriverManager.getConnection(url, nombre, contrasena);
       
        
    }

    public void DML(String consulta) throws SQLException {
        Statement sentencia = conexion.createStatement();
        sentencia.executeUpdate(consulta);
        sentencia.close();
    }

    public String Comprobar(String consulta) throws SQLException {
        Statement sentencia = conexion.createStatement();
        ResultSet resultado = sentencia.executeQuery(consulta);
        String resul = "";
        while (resultado.next()) {
            resul += resultado.getString(1) + "\n";
        }
        sentencia.close();
        return resul;
    }
    
       public String ComprobarCedula(String consulta) throws SQLException {
        Statement sentencia = conexion.createStatement();
        ResultSet resultado = sentencia.executeQuery(consulta);
        String resul = "";
        while (resultado.next()) {
            resul += resultado.getString(1);
        }
        sentencia.close();
        return resul;
    }

    public String MostrarDepartamento(String consulta) throws SQLException {
        Statement sentencia = conexion.createStatement();
        ResultSet resultado = sentencia.executeQuery(consulta);
        String resul = "";
        while (resultado.next()) {
            resul += resultado.getString(1) + " " + resultado.getString(2) + "\n";
        }
        sentencia.close();
        return resul;
    }

    public String MostrarEmpleado(String consulta) throws SQLException {
        Statement sentencia = conexion.createStatement();
        ResultSet resultado = sentencia.executeQuery(consulta);
        String resul = "";
        while (resultado.next()) {
            resul += resultado.getString(1) + " " + resultado.getString(2) + resultado.getString(3) + resultado.getString(4) + "\n";
        }
        sentencia.close();
        return resul;
    }

}
