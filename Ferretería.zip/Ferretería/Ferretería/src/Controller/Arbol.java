/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;
import Model.Nodo;
/**
 *
 * @author user
 */
public class Arbol {
    public Nodo Raiz; //ptr inicio
    
    public Arbol(){
        Raiz=null;
    }
    // Métodos
     public void Insertar(Nodo R, Nodo dato)
{
	if(R==null)
	{
		Raiz= new Nodo(dato);
		return;
	}
	if(dato.codigopr<R.codigopr)
	{
		if(R.LI==null)R.LI=new Nodo(dato);
		else
		  Insertar(R.LI,dato);
	}else
	   if(dato.codigopr>R.codigopr)
	   {
		  if(R.LD==null)R.LD=new Nodo(dato);
		  else
		    Insertar(R.LD,dato);
	   }
	    else
		  System.err.println("Error- dato duplicado");
}
     // IMPRIMIR
    public void Preorden(Nodo R){
        
	if(R!=null)
	{
		imprimenodo(R);
		Preorden(R.LI);
                Preorden(R.LD);
        }    
        
}
    //IMPRIME NODO QUE RECIBE
    public void imprimenodo(Nodo R){ 
        System.out.println("CÓDIGO DEL PRODUCTO: "+R.codigopr+
                           " NOMBRE DEL PRODUCTO: "+R.nombrepr+
                           " STOCK ACTUAL: "+R.stockactual+
                           " STOCK MÍNIMO: "+R.stockminimo+
                           " PRECIO UNITARIO: "+R.preciouni+
                           " SUCURSAL: "+R.sucursal);    
    }
    // 5. Total de plata invertido en mercancía (stock actual* precio unitario)
    public void totalplata(Nodo R){
        if (R!=null){
            R.total = R.stockactual * R.preciouni;
            System.out.println("EL TOTAL DE PLATA INVERTIDA EN MERCANCÍA ES: "+R.total);
            totalplata(R.LI);
            totalplata(R.LD);
        }
    }
    //6. Listado de artículos cuyo precio sea superior a $1.500
    double precio = 1500.0;
    public void preciosuperior(Nodo R){
        if(R!=null){
            if(R.preciouni>precio){
                System.out.println("El código de este artículo es: "+R.codigopr);
                imprimenodo(R);
            }
        }
    }

} // END CLASS ARBOL
