/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author user
 */
public class Nodo {
    public Nodo LI; //ptr
    public int codigopr;
    public String nombrepr;
    public double stockactual;
    public double stockminimo;
    public double preciouni;
    public String sucursal;
    public double total;
    public Nodo LD; //ptr
    
    public Nodo(){
        LI = null;
        LD = null;
    }
    
     public Nodo(Nodo empresa){
        codigopr = empresa.codigopr;
        nombrepr = empresa.nombrepr;
        stockactual = empresa.stockactual;
        stockminimo = empresa.stockminimo;
        preciouni = empresa.preciouni;
        sucursal = empresa.sucursal;
        total = empresa.total;
        LI = null;
        LD = null;
}
}